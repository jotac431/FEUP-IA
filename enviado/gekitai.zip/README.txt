O ficheiro deve ser compilado com o camando:
javac gekitai.java
e corrido com o comando:
java gekitai 

No jogo é possivel escolher dois modos
Player Vs Player
Player Vs Computer

No modo Player Vs Computer é possivel escolher entre
o modo easy (profundidade 1) e o modo hard (profundidade 3)

Quem começa o jogo é escolhido de forma aleatoria e vai alternando
até haver um vencedor.